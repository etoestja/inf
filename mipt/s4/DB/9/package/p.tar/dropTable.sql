use theater

drop table actorrolestaging_performance;
drop table actor_rolestaging;
drop table role_staging;
drop table play_staging;

drop table actor_actorTitle;
drop table actor_line;
drop table actor;
drop table actorTitle;

drop table seat_performance;
drop table seat;
drop table room;

drop table castReplace;
drop table performance;
drop table cast_staging;

drop table [cast];

drop table play_author;
drop table author;
drop table role_play;
drop table play;
drop table [role];
drop table staging;
drop table director;

drop table seatType;
drop table roleType;
drop table line;
drop table gender;
go

use master;

--drop database theater;